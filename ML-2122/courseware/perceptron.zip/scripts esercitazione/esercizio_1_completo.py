import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from sklearn.linear_model import  Perceptron

###fase 1
# generazione primo dataset
result_array = []
for i in range(5):
	for j in range(5):
		result_array.append([i,j])
	
r_arr = np.array(result_array)	#quadrato blu
		

result_array = []
for i in range(5):
	for j in range(5):
		result_array.append([i+5,j+5])
r_arr_2 = np.array(result_array) #quadrato rosso	

# faccio lo scatter plot del dataset
plt.scatter(r_arr[:,0],r_arr[:,1], color='b')
plt.scatter(r_arr_2[:,0], r_arr_2[:,1], color='r')
plt.show()


classi = np.vstack((r_arr,r_arr_2))

# genero le labels
y = []
for i in range(50):
	if i < 25:
		y.append(0)
	else:
		y.append(1)
		


X_train, X_test, y_train, y_test = train_test_split(classi, y, test_size=0.3)

ppn = Perceptron(n_iter=100, eta0=0.01, random_state=0)

sc = StandardScaler()
sc.fit(X_train)


# Apply the scaler to the X training data
X_train_std = sc.transform(X_train)

# Apply the SAME scaler to the X test data
X_test_std = sc.transform(X_test)
# Train the perceptron
ppn.fit(X_train_std, y_train)
# Apply the trained perceptron on the X data to make predicts for the y test data
y_pred = ppn.predict(X_test_std)

# View the accuracy of the model, which is: 1 - (observations predicted wrong / total observations)
print('Accuracy: %.2f' % accuracy_score(y_test, y_pred))


####fase 2

result_array = []
for i in range(5):
	for j in range(5):
		result_array.append([i+2.3,j+2.3])
r_arr_3 = np.array(result_array)	
classiv2 = np.vstack((r_arr,r_arr_3))	

plt.scatter(r_arr_3[:,0], r_arr_3[:,1], color='r')
plt.scatter(r_arr[:,0],r_arr[:,1], color='b')
plt.show()

X_train, X_test, y_train, y_test = train_test_split(classiv2, y, test_size=0.3)
ppn = Perceptron(n_iter=100, eta0=0.01, random_state=0)
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)
ppn.fit(X_train_std, y_train)
y_pred = ppn.predict(X_test_std)
print('Accuracy: %.2f' % accuracy_score(y_test, y_pred))
y_true = y_test
print(confusion_matrix(y_true, y_pred))