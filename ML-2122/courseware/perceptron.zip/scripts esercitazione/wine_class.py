import numpy as np
import pandas as pd
from sklearn.linear_model import Perceptron
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
np.set_printoptions(threshold=np.inf)

#lo script deve essere eseguito nella cartella che contiene questo file
data_wine_file = "wine-data.csv"

#carico i dati dal file
df_wine = pd.read_csv(data_wine_file, header = 0)

wine_array = df_wine.as_matrix()


y = wine_array[:,0]

#print target_training_array
X = wine_array[:,1:14]

X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.70, random_state = 42)

scaler = preprocessing.StandardScaler().fit(X_train)
X_train_transformed = scaler.transform(X_train)
X_test_transformed = scaler.transform(X_test)
#print training_array

clf = Perceptron(max_iter=100, eta0=1)

clf.fit(X_train_transformed, y_train)

print(clf.score(X_test_transformed,y_test))

y_true = y_test

print(confusion_matrix(y_true, clf.predict(X_test_transformed)))












